#!/usr/bin/env python

# Web-Shortcuts

# Google
# Harry Beadle
# 11 JUN 14

Query = raw_input()

URL = "http://www.google.com/search?q=" + Query

print URL