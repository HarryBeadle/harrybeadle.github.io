# Help: Uninstalling #

To uninstall simple run the `Uninstall` program in this directory.