# Installation #

1. Select the packages that you want to install.
2. Drag the files onto the `Install Services` program located in this directory. This will overwrite any pervious versions of the software you have installed.
3. Run the program from the services menu or navigate to `System Preferences > Shortcuts > Services` and set-up key bindings there.

# Uninstallation #

To uninstall