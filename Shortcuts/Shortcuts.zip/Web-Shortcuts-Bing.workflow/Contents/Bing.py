#!/usr/bin/env python

# Web-Shortcuts

# Bing
# Harry Beadle
# 11 JUN 14

Query = raw_input()

URL = "http://www.bing.com/search?q=" + Query

print URL